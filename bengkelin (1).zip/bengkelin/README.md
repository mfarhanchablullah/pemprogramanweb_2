Aplikasi bengkelin merupakan aplikasi yang dapat digunakan untuk mengelola bengkel.
Mulai dari mencatat biaya-biaya jasa yang ada di bengkel tersebut, aplikasi kasir untuk pembayaran, pencatatan atau pemdaftaran moyor yang akan di service, laporan transaksi yang dapat dilihat mulai dari tanggal kapan saja hingga kapan saja sesuai kebutuhan.
Aplikasi ini dibangun menggunakan php 7 dan databade mysql dengan framework codrigniter 4.
